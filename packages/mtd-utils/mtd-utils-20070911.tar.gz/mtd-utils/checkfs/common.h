/* $Id: common.h,v 1.1 2001/06/21 23:07:56 dwmw2 Exp $ */
//this .h file is common to both the file creation utility and
//the file checking utility.
#define TRUE    1
#define FALSE   0

#define MAX_NUM_FILES    100
