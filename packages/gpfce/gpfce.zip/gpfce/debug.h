void DumpMem(char *fname, uint32 start, uint32 end);

