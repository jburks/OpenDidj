int  FCEUI_Initialize098(void);
void FCEUI_Emulate098(void);
void ResetNES098(void);

