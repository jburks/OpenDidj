#include "types.h"
int InitVirtualVideo(void);
int SaveSnapshot(void);
extern uint8 *XBuf;
