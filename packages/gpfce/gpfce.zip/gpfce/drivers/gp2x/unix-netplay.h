extern char *netplayhost;
extern int Port;
extern int FDnetplay;
#define netplay FDnetplay

