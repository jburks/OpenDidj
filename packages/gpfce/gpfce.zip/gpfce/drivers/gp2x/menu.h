
extern char menuErrorMsg[40];

int gp2x_menu_do(void);

