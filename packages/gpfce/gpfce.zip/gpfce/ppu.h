
extern uint8 SPRAM[0x100];
//extern uint8 SPRBUF[0x100];
extern void FetchSpriteData(void);
extern void RefreshSprites(void);
extern void CopySprites(uint8 *target);

